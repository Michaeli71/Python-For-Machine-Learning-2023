class Car:
    def __init__(self):
        self.brand = None
        self.color = None
        self.horse_power = 0


car = Car()