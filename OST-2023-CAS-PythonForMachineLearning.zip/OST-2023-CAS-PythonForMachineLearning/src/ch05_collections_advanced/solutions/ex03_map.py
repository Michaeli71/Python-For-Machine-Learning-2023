values1 = [100, 200, 300, 400, 500]
values2 = [10, 20, 30, 40, 50]

result = list(map(lambda x, y: x + y, values1, values2))

print(result)
