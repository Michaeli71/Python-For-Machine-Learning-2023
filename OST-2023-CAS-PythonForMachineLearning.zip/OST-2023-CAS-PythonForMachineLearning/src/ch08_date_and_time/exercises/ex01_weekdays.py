import datetime


def get_week_day(my_date):
    # TODO
    pass


def print_week_day(date):
    # TODO
    pass


christmas_eve = datetime.date(2019, 12, 24)
december1st = datetime.date(2019, 12, 1)
december31st = datetime.date(2019, 12, 31)

print_week_day(christmas_eve)
print_week_day(december1st)
print_week_day(december31st)
