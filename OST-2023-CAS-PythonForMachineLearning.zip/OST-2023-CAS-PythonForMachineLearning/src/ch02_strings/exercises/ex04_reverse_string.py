def reverse_string(input):
    # TODO
    pass


print(reverse_string("ABCDEFGHI"))
print(reverse_string("was it a car or a cat i saw"))