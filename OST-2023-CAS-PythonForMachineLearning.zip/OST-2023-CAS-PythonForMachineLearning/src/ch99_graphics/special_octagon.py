import turtle

for i in range(0,12):
    for i in range(8):
        turtle.forward(50)
        turtle.right(45)
    turtle.right(30)

turtle.hideturtle()
turtle.exitonclick()