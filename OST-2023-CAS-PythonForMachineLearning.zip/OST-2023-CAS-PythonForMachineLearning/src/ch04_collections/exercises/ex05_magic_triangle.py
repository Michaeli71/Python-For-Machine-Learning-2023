def is_magic6(values):
    pass


print(is_magic6([1, 5, 3, 4, 2, 6]))
print(is_magic6([1, 2, 3, 4, 5, 6]))


def is_magic_triangle(values):
   pass


print(is_magic_triangle([1, 5, 3, 4, 2, 6]))
print(is_magic_triangle([1, 2, 3, 4, 5, 6]))
